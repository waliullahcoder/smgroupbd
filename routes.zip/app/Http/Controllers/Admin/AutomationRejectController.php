<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AccountTransaction;
use App\Models\AccountTransactionAuto;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Facades\DataTables;

class AutomationRejectController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        if (request()->ajax()) {
            $query = AccountTransaction::with(['company'])
                ->whereNotIn('voucher_type', ['CV', 'DV', 'JV']);
            if (!is_null(request('voucher_date'))) {
                $date =  date('Y-m-d', strtotime(request('voucher_date')));
                $query->where('voucher_date', $date);
            }
            $model = $query->orderBY('id', 'desc')
                ->select('*', DB::raw('SUM(debit_amount) as amount'))
                ->orderBY('voucher_date', 'desc')->where('approve', 1)->groupBy('voucher_no');

            return DataTables::eloquent($model)
                ->addIndexColumn()
                ->addColumn('checkbox', function ($row) {
                    $checkbox = '<div class="custom-control custom-checkbox">
                    <input type="checkbox" class="custom-control-input multi_checkbox" id="' . $row->id . '" name="multi_checkbox[]" value="' . $row->id . '"><label for="' . $row->id . '" class="custom-control-label"></label></div>';
                    return $checkbox;
                })
                ->addColumn('voucher_date', function ($row) {
                    return date('d-m-Y', strtotime($row->voucher_date));
                })
                ->addColumn('debit_head', function ($row) {
                    return AccountTransaction::with('coa')->where('voucher_no', $row->voucher_no)
                        ->where('voucher_type', $row->voucher_type)
                        ->where('debit_amount', '>', 0)
                        ->get('coa_setup_id')->pluck('coa.head_name')->toArray();
                })
                ->addColumn('credit_head', function ($row) {
                    return AccountTransaction::with('coa')->where('voucher_no', $row->voucher_no)
                        ->where('voucher_type', $row->voucher_type)
                        ->where('credit_amount', '>', 0)
                        ->get('coa_setup_id')->pluck('coa.head_name')->toArray();
                })
                ->addColumn('actions', function ($row) {
                    return '<div class="justify-content-end d-flex gap-1">
                            <a class="btn btn-outline-info btn-xs text-nowrap px-2 tt" href="' . Route('admin.automation-reject.show', $row->id) . '" data-bs-toggle="tooltip" data-bs-placement="top" title="View"><i class="fas fa-eye"></i> View</a>
                            <button type="button" class="btn btn-outline-danger btn-xs text-nowrap approve-btn px-2 tt" data-url="' . Route('admin.automation-reject.edit', $row->id) . '" data-bs-toggle="tooltip" data-bs-placement="top" title="Approve"><i class="fa fa-thumbs-down"></i> Refuse</button></div>';
                })
                ->rawColumns(['checkbox', 'actions'])
                ->make(true);
        }
        $title = 'Refuse Automation';
        $params = '<input type="text" class="form-control dateFilter input-sm" id="voucher_date" name="voucher_date" style="width: 150px; min-height: auto;" value="" placeholder="Voucher Date">';
        return view('admin.refuse_automation.index', compact('title', 'params'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $title = "View Automation";
        $transaction = AccountTransaction::findOrFail($id);
        $transactions = AccountTransaction::where('voucher_no', $transaction->voucher_no)
            ->where('voucher_type', $transaction->voucher_type)->get();
        return view('admin.refuse_automation.view')->with(compact('title', 'transaction', 'transactions'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Request $request, string $id)
    {
        if ($request->ajax()) {
            try {
                DB::transaction(function () use ($id, $request) {
                    $ids = $request->id ?? [$id]; // single or multiple IDs
                    foreach ($ids as $id) {
                        $data = AccountTransaction::findOrFail($id);
                        AccountTransactionAuto::where('voucher_no', $data->voucher_no)
                            ->where('voucher_type', $data->voucher_type)
                            ->update([
                                'posted' => false,
                                'approve' => false,
                                'approve_by' => null,
                            ]);
                        AccountTransaction::where('voucher_no', $data->voucher_no)
                            ->where('voucher_type', $data->voucher_type)
                            ->forceDelete();
                    }
                });
                return response()->json(['status' => 'success']);
            } catch (\Exception $e) {
                return response()->json(['status' => 'error', 'message' => $e->getMessage()]);
            }
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
